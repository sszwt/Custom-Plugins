<?php
/**
 * Sanitization helpers.
 *
 * @package AABG
 */

namespace AABG\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Sanitizer
 */
class Sanitizer {

	/**
	 * Sanitize block slug.
	 *
	 * @param string $slug Raw slug.
	 * @return string
	 */
	public static function block_slug( $slug ) {
		return sanitize_title( $slug );
	}

	/**
	 * Sanitize block name input.
	 *
	 * @param string $name Block name.
	 * @return string
	 */
	public static function block_name( $name ) {
		return sanitize_text_field( wp_unslash( $name ) );
	}

	/**
	 * Sanitize prompt text.
	 *
	 * @param string $prompt Prompt.
	 * @return string
	 */
	public static function prompt( $prompt ) {
		return sanitize_textarea_field( wp_unslash( $prompt ) );
	}

	/**
	 * Sanitize field name for ACF.
	 *
	 * @param string $name Field name.
	 * @return string
	 */
	public static function field_name( $name ) {
		$name = strtolower( preg_replace( '/[^a-zA-Z0-9_]/', '_', $name ) );
		$name = preg_replace( '/_+/', '_', $name );
		return trim( $name, '_' );
	}
}
