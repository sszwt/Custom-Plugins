<?php
/**
 * Shared AI prompt and response helpers.
 *
 * @package AABG
 */

namespace AABG\AI;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Trait AI_Spec_Helper
 */
trait AI_Spec_Helper {

	/**
	 * System prompt for block analysis.
	 *
	 * @param bool $with_design Include design vision instructions.
	 * @return string
	 */
	protected function get_system_prompt( $with_design = false ) {
		$design_note = $with_design
			? ' When a design image is provided, you MUST analyze the visual design pixel-by-pixel and return layout_structure that EXACTLY matches the design. Use grid_system "theme" with WordPress theme grid classes: .row, .cell-md-6, .cell-md-4, .cell-12, align-items-center. Extract exact design_tokens (hex colors, spacing in rem/px, typography sizes) from the image. Map each visible UI element to an ACF field with correct wrapper width (50 for two-column admin layout). Match field placement to visual positions.'
			: ' Always set layout_structure.grid_system to "theme" and use cell_class values like cell-md-6, cell-md-4, cell-12 matching the layout.';

		return 'You are an expert WordPress and ACF developer building blocks for the plugins-demo theme (Zealous Web boilerplate). Analyze user prompts and return JSON for generating an ACF Gutenberg block.' . $design_note . '

THEME GRID SYSTEM (required for layout_structure):
- grid_system: "theme" (default, preferred) or "bem"
- Theme grid HTML: <div class="row align-items-center"><div class="cell-md-6">content</div><div class="cell-md-6">media</div></div>
- cell_class options: cell-12, cell-md-3, cell-md-4, cell-md-6, cell-md-8, cell-md-9, cell-lg-4, cell-lg-6
- Theme PHP helpers: acf_link($link, "btn"), acf_image($id), render_acf_block_preview($block)
- Theme SCSS: @use variables/function/mixins, respond-above("md"), rem(), $primary-100, $container-width

Return ONLY valid JSON with this structure:
{
  "purpose": "Brief block purpose",
  "layout": "hero|two-column|slider|accordion|tabs|grid|cta|content|team|testimonial|custom",
  "layout_details": "Layout description",
  "fields": [
    {
      "label": "Field Label",
      "name": "field_name_snake_case",
      "type": "acf_field_type",
      "instructions": "optional",
      "required": false,
      "default_value": "optional",
      "wrapper": { "width": "50" },
      "sub_fields": [],
      "layouts": [],
      "choices": {},
      "new_lines": "br"
    }
  ],
  "needs_javascript": false,
  "javascript_type": "none|slider|accordion|tabs|counter|popup|video|animation",
  "bem_block": "block-name",
  "css_notes": "responsive layout notes",
  "design_tokens": {
    "primary_color": "#hex from design",
    "text_color": "#hex from design",
    "background_color": "#hex from design",
    "section_padding": "4rem 0",
    "heading_size": "2.5rem",
    "gap": "1.5rem",
    "radius": "8px"
  },
  "layout_structure": {
    "grid_system": "theme",
    "rows": [
      {
        "align": "center",
        "columns": [
          {
            "width": "50%",
            "cell_class": "cell-md-6",
            "fields": ["field_name_1", "field_name_2"],
            "class": "col-content"
          },
          {
            "width": "50%",
            "cell_class": "cell-md-6",
            "fields": ["field_name_3"],
            "class": "col-media"
          }
        ]
      }
    ]
  },
  "suggestions": {
    "accessibility": ["tip1"],
    "performance": ["tip1"],
    "field_names": ["suggestion"],
    "reusable_groups": ["suggestion"]
  },
  "placeholder_content": {}
}

Supported ACF field types: text, textarea, image, gallery, link, url, email, number, color_picker, range, date_picker, select, checkbox, radio, true_false, file, relationship, post_object, taxonomy, repeater, flexible_content, group, clone, accordion, tab, message, button_group, wysiwyg.

For ANY repeating group of items (team members, cards, logos, features, testimonials, steps, stats), you MUST use a "repeater" field with a "sub_fields" array — never flatten repeated items into separate top-level fields. Each repeated card image/title/text becomes a sub_field.
For grid/cards/features/team layouts, set layout to the matching value and place the repeater field in a single full-width column (cell_class "cell-12"); the grid columns are handled by CSS automatically.
For two-column or hero layouts, split fields into exactly two columns in layout_structure with cell_class values that add up to 12 (e.g. cell-md-6 + cell-md-6, or cell-md-7 + cell-md-5) matching the visual proportions in the design.
For flexible_content include layouts array with name, label, sub_fields.
Set needs_javascript true only for interactive features: slider, accordion, tabs, counter, popup, video, animation.
Use semantic, snake_case, prefixed field names. Include slider settings (autoplay, navigation) when relevant.';
	}

	/**
	 * Build user message JSON.
	 *
	 * @param string $prompt       Prompt.
	 * @param array  $block_config Config.
	 * @return string
	 */
	protected function build_user_message( $prompt, $block_config ) {
		return wp_json_encode(
			array(
				'block_name'        => $block_config['name'] ?? '',
				'block_slug'        => $block_config['slug'] ?? '',
				'block_category'    => $block_config['category'] ?? 'custom-blocks',
				'block_description' => $block_config['description'] ?? '',
				'user_prompt'       => $prompt,
			)
		);
	}

	/**
	 * Normalize AI response.
	 *
	 * @param array  $parsed       Parsed response.
	 * @param array  $block_config Block config.
	 * @param string $source       Provider source tag.
	 * @return array
	 */
	protected function normalize_response( $parsed, $block_config, $source = 'ai' ) {
		$parsed['block_name']        = $block_config['name'] ?? '';
		$parsed['block_slug']        = $block_config['slug'] ?? '';
		$parsed['block_category']    = $block_config['category'] ?? 'custom-blocks';
		$parsed['block_icon']        = $block_config['icon'] ?? 'layout';
		$parsed['block_description'] = $block_config['description'] ?? '';
		$parsed['source']            = $source;

		if ( empty( $parsed['fields'] ) || ! is_array( $parsed['fields'] ) ) {
			$parsed['fields'] = array();
		}

		if ( empty( $parsed['bem_block'] ) ) {
			$parsed['bem_block'] = $block_config['slug'] ?? 'aabg-block';
		}

		if ( empty( $parsed['layout_structure'] ) ) {
			$parsed['layout_structure'] = $this->infer_layout_structure( $parsed );
		}

		return $parsed;
	}

	/**
	 * Infer row/column structure when AI omits it.
	 *
	 * @param array $parsed Parsed spec.
	 * @return array
	 */
	protected function infer_layout_structure( $parsed ) {
		$fields  = $parsed['fields'] ?? array();
		$layout  = $parsed['layout'] ?? 'content';
		$content = array();
		$media   = array();

		foreach ( $fields as $field ) {
			$name = $field['name'] ?? '';
			$type = $field['type'] ?? 'text';
			if ( ! $name || in_array( $type, array( 'accordion', 'tab', 'message', 'true_false' ), true ) ) {
				continue;
			}
			if ( in_array( $type, array( 'image', 'gallery', 'file' ), true ) || false !== strpos( $name, 'image' ) ) {
				$media[] = $name;
			} else {
				$content[] = $name;
			}
		}

		if ( in_array( $layout, array( 'hero', 'two-column' ), true ) && ! empty( $media ) && ! empty( $content ) ) {
			return array(
				'grid_system' => 'theme',
				'rows'        => array(
					array(
						'align'   => 'center',
						'columns' => array(
							array(
								'width'      => '50%',
								'cell_class' => 'cell-md-6',
								'fields'     => $content,
								'class'      => 'col-content',
							),
							array(
								'width'      => '50%',
								'cell_class' => 'cell-md-6',
								'fields'     => $media,
								'class'      => 'col-media',
							),
						),
					),
				),
			);
		}

		$all = array_merge( $content, $media );
		return array(
			'grid_system' => 'theme',
			'rows'        => array(
				array(
					'columns' => array(
						array(
							'width'      => '100%',
							'cell_class' => 'cell-12',
							'fields'     => $all,
							'class'      => 'col-full',
						),
					),
				),
			),
		);
	}
}
